import React from 'react';
import Header from './components/Header.jsx'
import Footer from './components/Footer.jsx'
import './App.css'

export default function App() {
    return (
        <>
        <Header />
        <main className="container">
            <h1>Hello, React!</h1>
            <p>Первый React проект на Vite.</p>
        </main>
        <Footer />
        </>
    )
}
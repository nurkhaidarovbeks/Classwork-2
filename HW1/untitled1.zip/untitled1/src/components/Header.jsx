import React from 'react';

export default function Header() {
    return (
        <header className="header">
            <div className="container header__inner">
                <span className="logo">MyReactApp</span>
                <nav>
                    <a href="#">Home</a> | <a href="#">About</a>
                </nav>
            </div>
        </header>
    )
}